$(function() {
    var token = $('meta[name=csrf-token]').attr("content");
    $('body').off('click', '.go-filtr');
    $('body').on('click', '.go-filtr', function (e) {
        e.preventDefault();
        var page = $(this).data("page");
        var field = $(this).data("field");
        var value = $(this).data("value");
        $.ajax({
            type: "POST",
            url: "/profile/tables/filtr/",
            data:{"_csrf-backend":token, page:page, field:field, value:value},
            success: function() {
                $('#' + page).trigger('click');
            },
        }).fail(function (xhr) {
            console.log(xhr. responseText);
        });
    });

    $('body').off('click', '.del-filtr');
    $('body').on('click', '.del-filtr', function (e) {
        e.preventDefault();
        var page = $(this).data("page");
        var field = $(this).data("field");
        $.ajax({
            type: "POST",
            url: "/profile/tables/delfiltr/",
            data:{"_csrf-backend":token, page:page, field:field},
            success: function() {
                $('#' + page).trigger('click');
            },
        }).fail(function (xhr) {
            console.log(xhr. responseText);
        });
    });
});
