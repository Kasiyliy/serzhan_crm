$(function() {
    var form = $("#form");

    /* Форма для боксера */
    form.validate({
        ignore: 'input[type=hidden]',
        errorClass: 'validation-error-label',
        successClass: 'validation-valid-label',
        highlight: function(element, errorClass) {
            $(element).removeClass(errorClass);
        },
        unhighlight: function(element, errorClass) {
            $(element).removeClass(errorClass);
        },

        validClass: "validation-valid-label",
        success: function(label) {
            label.addClass("validation-valid-label").text("Принято.")
        },

        submitHandler: function () {
            var form = document.getElementById("form");
            var msg = new FormData(form);
            $.ajax({
                dataType: "json",
                type: "POST",
                url: "/profile/moderators/driver/",
                data: msg,
                cache: true,
                contentType: false,
                processData: false,
                status: startLoading($("#form")),
                success: function (data) {
                    var redirect = null;
                    $("#form").unblock();
                    if (data.type == "information") {
                        setTimeout(function () {
                            window.location.href = "/profile/authentication/";
                        }, 2000);
                    } else if (data.type == "success") {

                        redirect = "drivers";
                    }
                    SendSwal(data.message, data.type, redirect);
                },
            }).fail(function (xhr) {
                console.log(xhr.responseText);
            });
            //return false;
        }
    });
    function startLoading(block) {
        $(block).block({
            message: '<i class="icon-spinner4 spinner"></i>',
            overlayCSS: {
                backgroundColor: 'rgba(63, 158, 195, 0.59)',
                opacity: 1,
                cursor: 'wait'
            },
            css: {
                border: 0,
                padding: 0,
                color: '#fff',
                backgroundColor: 'transparent'
            }
        });
    }

    function SendSwal(message, type, link) {
        swal({
            title: message,
            timer: 900,
            type: type,
            showConfirmButton: false
        });
        if (link != null) {

            $('#' + link).trigger('click');
        }
    }

});
