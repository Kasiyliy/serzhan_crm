$(function() {
    var token = $('meta[name=csrf-token]').attr("content");
    $.extend( $.fn.dataTable.defaults, {
        autoWidth: false,
        responsive: true,
        dom: '<"datatable-header"fl><"datatable-scroll-wrap"t><"datatable-footer"ip>',
        language: {
            "emptyTable":       "Данные отсутствуют.",
            "info":             "Показано с _START_ по _END_, всего: _TOTAL_",
            "infoEmpty":        "Показано 0 из 0, всего 0",
            "infoFiltered":     "(отфильтровано из _MAX_)",
            "infoPostFix":      "",
            "lengthMenu":       "<span>Показано:</span> _MENU_",
            "loadingRecords":   "Загрузка...",
            "processing":       "Загрузка...",
            "search":           "<span>Поиск:</span> _INPUT_",
            "searchPlaceholder": 'Введите ключевые слова...',
            "zeroRecords":      "Данные отсутствуют.",
            "paginate": {
                "first":        "Первая",
                "previous":     "&larr;",
                "next":         "&rarr;",
                "last":         "Последняя"
            },
            "aria": {
                "sortAscending":    ": activate to sort column ascending",
                "sortDescending":   ": activate to sort column descending"
            },
            "decimal":          "",
            "thousands":        ","
        },


        drawCallback: function () {
            $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').addClass('dropup');
        },
        preDrawCallback: function() {
            $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').removeClass('dropup');
        }
    });
    $('.table').DataTable({
        ajax: {
            "url":"/profile/tables/gettable/",
            "type": 'POST',
            "data": {"_csrf-backend":token, table:"users", name:"tadmins"}
        },
        aoColumns: [
            {
                "data": 0,
                "mRender": function (data, type, row) {
                    return '<span style="float:left;">' + data + '</span><span style="float:right; margin-top: 2px;"><ul class="icons-list" style="float:left;"><li><a class="action-link" data-id="'+ data +'" title = "Редактировать" href="tadmins/form-tadmin"><i style="font-size:0.9em; margin-top:2px;" class="icon-pencil"></i></a></li></ul></span>';
                }
            },
            {"data": 1},
            {"data": 2},
            {"data": 5},
            {"data": 6},
            {"data": 3},

        ],
        order: [[ 4, 'desc' ]],
    });

    $('.dataTables_length select').select2({
        minimumResultsForSearch: Infinity,
        width: 'auto'
    });

});
