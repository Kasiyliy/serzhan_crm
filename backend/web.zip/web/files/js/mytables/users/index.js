$(function() {
    var token = $('meta[name=csrf-token]').attr("content");
    $.extend( $.fn.dataTable.defaults, {
        autoWidth: false,
        responsive: true,
        dom: '<"datatable-header"fl><"datatable-scroll-wrap"t><"datatable-footer"ip>',
        language: {
            "emptyTable":       "Данные отсутствуют.",
            "info":             "Показано с _START_ по _END_, всего: _TOTAL_",
            "infoEmpty":        "Показано 0 из 0, всего 0",
            "infoFiltered":     "(отфильтровано из _MAX_)",
            "infoPostFix":      "",
            "lengthMenu":       "<span>Показано:</span> _MENU_",
            "loadingRecords":   "Загрузка...",
            "processing":       "Загрузка...",
            "search":           "<span>Поиск:</span> _INPUT_",
            "searchPlaceholder": 'Введите ключевые слова...',
            "zeroRecords":      "Данные отсутствуют.",
            "paginate": {
                "first":        "Первая",
                "previous":     "&larr;",
                "next":         "&rarr;",
                "last":         "Последняя"
            },
            "aria": {
                "sortAscending":    ": activate to sort column ascending",
                "sortDescending":   ": activate to sort column descending"
            },
            "decimal":          "",
            "thousands":        ","
        },


        drawCallback: function () {
            $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').addClass('dropup');
        },
        preDrawCallback: function() {
            $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').removeClass('dropup');
        }
    });



    $('.table').on( 'draw.dt', function () {
        $(".switch").bootstrapSwitch().off('switchChange.bootstrapSwitch');
        $(".switch").bootstrapSwitch().on('switchChange.bootstrapSwitch', function () {

            var th = $(this);
            console.log(th.data("id"));
            if ($(this).is(':checked')) {
                swal({
                        title: "Вы уверены, что хотите разблокировать пользователя?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#2196F3",
                        confirmButtonText: "Подтверждаю",
                        cancelButtonText: "Отмена",
                        closeOnConfirm: true,
                        closeOnCancel: true
                    },
                    function (isConfirm) {

                        if (isConfirm) {
                            console.log('confirm')
                            $.ajax({
                                type: "POST",
                                url: "/profile/account/set-status/",
                                data: {"_csrf-backend":token, status:1, id: th.data("id")},

                            });
                        } else {
                            th.bootstrapSwitch('state', false);
                            console.log('not confirm')

                        }
                    });
            } else {
                swal({
                        title: "Вы уверены, что хотите заблокировать пользователя?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#2196F3",
                        confirmButtonText: "Подтверждаю",
                        cancelButtonText: "Отмена",
                        closeOnConfirm: true,
                        closeOnCancel: true
                    },
                    function (isConfirm) {

                        if (isConfirm) {
                            console.log('confirm')
                            $.ajax({
                                type: "POST",
                                url: "/profile/account/set-status/",
                                data: {"_csrf-backend":token, status:0, id: th.data("id")},

                            });

                        } else {
                            th.bootstrapSwitch('state', true);
                            console.log('not confirm')

                        }
                    });

            }
            console.log($(this).data("id"))
        });
    } );


    $('.table').DataTable({
        ajax: {
            "url":"/profile/tables/gettable/",
            "type": 'POST',
            "data": {"_csrf-backend":token, table:"users", name:"users"}
        },
        aoColumns: [
            {
                "data": 0,
                "mRender": function (data, type, row) {
                    return '<span style="float:left;">' + data + '</span><span style="float:right; margin-top: 2px;"><ul class="icons-list" style="float:left;"><li><a class="action-link" data-id="'+ data +'" title = "Редактировать" href="moderators/form-moderator"><i style="font-size:0.9em; margin-top:2px;" class="icon-pencil"></i></a></li></ul></span>';
                }
            },
            {"data": 1},
            {"data": 2},
            {"mData": {},
                "mRender": function (data, type, row) {
                    var status = null;
                    if (data[6] == 1) {
                        status = '<input checked = "checked" data-id="' + data[0] + '" value = "1" type="checkbox" data-on-color="success" data-off-color="danger" data-on-text="Активный" data-off-text="Залокирован" class="switch">';
                    } else if (data[6] == 0) {
                        status = '<input value = "1" data-id="' + data[0] + '" type="checkbox" data-on-color="success" data-off-color="danger" data-on-text="Активный" data-off-text="Залокирован" class="switch">';
                    }

                    return status;


                }
            },
            {
                "data":3
            },
        ],
        order: [[ 4, 'desc' ]],
    });

    $('.dataTables_length select').select2({
        minimumResultsForSearch: Infinity,
        width: 'auto'
    });

});
